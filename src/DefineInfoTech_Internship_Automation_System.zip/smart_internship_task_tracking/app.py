import os,streamlit as st,pandas as pd,plotly.express as px
from datetime import date
from config.settings import LOGO
from database.connection import init_db,connect
from services.core import authenticate,hash_password,seed,tasks,deadlines,save_intern,save_task,audit,backup,allowed
from services.core import verify_password
from services.core import *
from services.core import audit
from reportlab.lib.pagesizes import A4,landscape
from reportlab.platypus import SimpleDocTemplate,Paragraph,Table,TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from io import BytesIO
st.set_page_config(page_title='Internship Task Tracking Automation',layout='wide',page_icon='📘')
init_db()
with connect() as c:
 if not c.execute("SELECT 1 FROM users WHERE role='admin'").fetchone():
  pw=os.getenv('ADMIN_INITIAL_PASSWORD','')
  if len(pw)>=12:c.execute('INSERT INTO users(username,password_hash,role) VALUES(?,?,?)',(os.getenv('ADMIN_USERNAME','admin'),hash_password(pw),'admin'))
# Local demonstration mode: open the dashboard directly without a login screen.
# Do not deploy this no-login configuration to a public or shared network.
if 'user' not in st.session_state:
 st.session_state.user={'username':'demo_admin','role':'admin','intern_id':None,'team_id':None}
 with connect() as c:
  has_interns=c.execute('SELECT COUNT(*) FROM interns').fetchone()[0]
 if not has_interns:
  seed()

def login():
 st.markdown('<style>.stApp{background:linear-gradient(135deg,#07152f,#123768);color:#f5f7fb}</style>',unsafe_allow_html=True)
 a,b,c=st.columns([1,2,1])
 with b:
  if LOGO.exists():st.image(str(LOGO),width=320)
  st.title('DefineInfoTech Pvt. Ltd.');st.subheader('Smart Internship Task Tracking & Automation')
  with st.form('login'):
   u=st.text_input('Username');p=st.text_input('Password',type='password');ok=st.form_submit_button('Sign in',use_container_width=True)
  if ok:
   x=authenticate(u,p)
   if x:st.session_state.user=x;st.rerun()
   else:st.error('Login failed. Verify credentials or active status.')
  st.info('First run: copy .env.example to .env and set ADMIN_INITIAL_PASSWORD to a strong password (12+ characters), then restart.')

def main(user):
 with st.sidebar:
  if LOGO.exists():st.image(str(LOGO),width=200)
  st.markdown('### Internship Automation');st.write('Demo Mode · Administrator');st.caption('Local demonstration only — authentication is disabled.')
  pages=['Dashboard','Intern Management','Team Management','Task Management','Attendance','Assessments','Deadline Monitoring','Reports & Exports','Excel Import Center','Data Quality','Audit Logs','User Management','Backup & Settings','User Guide','Change Password']
  if user['role']!='admin':pages=[x for x in pages if x not in ['Team Management','Excel Import Center','Audit Logs','User Management','Backup & Settings']]
  page=st.radio('Navigation',pages)
  if st.button('Reset dashboard session'):st.rerun()
 st.title(page)
 if page=='Dashboard':
  ts=tasks(user);ds=deadlines(user)
  with connect() as c:
   if user['role']=='admin':ni=c.execute('SELECT COUNT(*) FROM interns WHERE active=1').fetchone()[0];nt=c.execute('SELECT COUNT(*) FROM teams WHERE active=1').fetchone()[0]
   elif user['role']=='team_lead':ni=c.execute('SELECT COUNT(*) FROM interns WHERE active=1 AND team_id=?',(user['team_id'],)).fetchone()[0];nt=1
   else:ni=1;nt=0
  passed=sum(t['assessment_status']=='Passed' for t in ts);vals=[('Active interns',ni),('Teams',nt),('Assigned tasks',len(ts)),('Not started',sum(t['status']=='Not Started' for t in ts)),('In progress',sum(t['status']=='In Progress' for t in ts)),('Awaiting review',len(ds['review_pending'])),('Overdue',len(ds['overdue'])),('Passed',passed),('Needs revision',len(ds['revision'])),('Completion %',round(passed/len(ts)*100,1) if ts else 0)]
  cols=st.columns(5)
  for i,(k,v) in enumerate(vals):cols[i%5].metric(k,v if k!='Completion %' else f'{v}%')
  if ts:
   df=pd.DataFrame(ts);a,b=st.columns(2);a.plotly_chart(px.pie(df,names='status',title='Task Status Distribution'),use_container_width=True)
   q=df.groupby('team_id').agg(total=('task_id','count'),passed=('assessment_status',lambda s:(s=='Passed').sum())).reset_index();q['completion %']=(q.passed/q.total*100).round(1);b.plotly_chart(px.bar(q,x='team_id',y='completion %',title='Team-wise Successful Assessment %',range_y=[0,100]),use_container_width=True)
   # Transparent, automated task-risk scoring derived from stored task data.
   today_s=date.today().isoformat()
   def classify_risk(r):
    if r.get('assessment_status')=='Passed': return 'Low'
    if r.get('status') not in ('Submitted','Reviewed') and r.get('due_date','') < today_s: return 'High'
    if r.get('priority') in ('High','Critical') or r.get('assessment_status')=='Needs Revision': return 'High'
    if r.get('priority')=='Medium' or (r.get('due_date','') <= (date.today()+pd.Timedelta(days=3)).date().isoformat() and r.get('status') not in ('Submitted','Reviewed')): return 'Medium'
    return 'Low'
   df['Risk Level']=df.apply(classify_risk,axis=1)
   risk=df.groupby(['full_name','Risk Level']).size().reset_index(name='Task Count')
   st.plotly_chart(px.bar(risk,x='full_name',y='Task Count',color='Risk Level',barmode='stack',category_orders={'Risk Level':['Low','Medium','High']},title='Intern-wise Work Risk (automatically calculated)',labels={'full_name':'Intern','Task Count':'Number of tasks'}),use_container_width=True)
   st.caption('Risk rule: High = overdue unfinished task, High/Critical priority, or Needs Revision; Medium = Medium priority or due within 3 days; Low = otherwise or successfully Passed. This is an operational heuristic, not an official DIT policy.')
   st.dataframe(df,use_container_width=True,hide_index=True)
  if user['role']=='admin' and st.button('Load synthetic demonstration data'):seed();st.success('Demo data loaded. Demo credentials are documented in README.');st.rerun()
 elif page=='Intern Management':
  if user['role']=='admin':
   with connect() as c:teams=[dict(r) for r in c.execute('SELECT * FROM teams WHERE active=1')]
   if teams:
    with st.form('intern'):
     a,b=st.columns(2);iid=a.text_input('DIT Internship ID');name=b.text_input('Full name');email=a.text_input('Email');phone=b.text_input('Contact number');team=b.selectbox('Team',teams,format_func=lambda t:f"{t['team_id']} — {t['team_name']}");start=a.date_input('Start date');end=b.date_input('End date');ok=st.form_submit_button('Save intern')
    if ok:
     try:save_intern(dict(intern_id=iid,full_name=name,email=email,phone=phone,team_id=team['team_id'],start_date=str(start),end_date=str(end)),user['username']);st.success('Intern saved')
     except Exception as e:st.error(str(e))
  with connect() as c:
   q='SELECT i.*,t.team_name FROM interns i JOIN teams t ON i.team_id=t.team_id';args=[]
   if user['role']=='team_lead':q+=' WHERE i.team_id=?';args=[user['team_id']]
   elif user['role']=='intern':q+=' WHERE i.intern_id=?';args=[user['intern_id']]
   df=pd.read_sql_query(q,c,params=args)
  st.dataframe(df,use_container_width=True,hide_index=True)
  if not df.empty:st.download_button('Export intern register',df.to_csv(index=False).encode(),'interns.csv')
 elif page=='Team Management':
  with connect() as c:df=pd.read_sql_query('SELECT t.*,COUNT(i.intern_id) member_count FROM teams t LEFT JOIN interns i USING(team_id) GROUP BY t.team_id',c)
  st.dataframe(df,use_container_width=True,hide_index=True)
  with st.form('team'):
   tid=st.text_input('Team ID');tn=st.text_input('Team name');lead=st.text_input('Team lead username');ok=st.form_submit_button('Save team')
  if ok:
   if not tid or not tn:st.error('Team ID and name required')
   else:
    with connect() as c:c.execute('INSERT INTO teams(team_id,team_name,lead_username) VALUES(?,?,?) ON CONFLICT(team_id) DO UPDATE SET team_name=excluded.team_name,lead_username=excluded.lead_username',(tid.upper(),tn,lead or None))
    audit(user['username'],'save_team','team',tid);st.success('Team saved');st.rerun()
 elif page=='Task Management':
  if user['role']=='admin':
   with connect() as c:interns=[dict(r) for r in c.execute('SELECT intern_id,team_id FROM interns WHERE active=1')]
   if interns:
    with st.expander('Create / update task'):
     with st.form('task'):
      a,b=st.columns(2);tid=a.text_input('Task ID');title=b.text_input('Title');intern=a.selectbox('Intern',interns,format_func=lambda x:x['intern_id']);ass=a.date_input('Assigned date');due=b.date_input('Due date');status=a.selectbox('Status',['Not Started','In Progress','Submitted','Reviewed']);assessment=b.selectbox('Assessment',['Pending','Passed','Needs Revision']);priority=a.selectbox('Priority',['Low','Medium','High','Critical']);sub=b.date_input('Submission date (optional)',value=None);comments=st.text_area('Reviewer comments');ok=st.form_submit_button('Save task')
     if ok:
      try:save_task(dict(task_id=tid,title=title,intern_id=intern['intern_id'],team_id=intern['team_id'],assigned_date=str(ass),due_date=str(due),submission_date=str(sub) if sub else None,status=status,assessment_status=assessment,priority=priority,reviewer_comments=comments,reviewed_by=user['username']),user['username']);st.success('Task saved');st.rerun()
      except Exception as e:st.error(str(e))
  df=pd.DataFrame(tasks(user));search=st.text_input('Search tasks')
  if not df.empty:
   if search:df=df[df.astype(str).apply(lambda col:col.str.contains(search,case=False,na=False)).any(axis=1)]
   st.dataframe(df,use_container_width=True,hide_index=True)
 elif page=='Attendance':
  with connect() as c:
   q='SELECT a.*,i.full_name,i.team_id FROM attendance a JOIN interns i USING(intern_id)';args=[]
   if user['role']=='team_lead':q+=' WHERE i.team_id=?';args=[user['team_id']]
   elif user['role']=='intern':q+=' WHERE i.intern_id=?';args=[user['intern_id']]
   rows=[dict(x) for x in c.execute(q,args)]
  eligible=[x for x in rows if x['status'] in ('Present','Absent')];pct=100*sum(x['status']=='Present' for x in eligible)/len(eligible) if eligible else 0;st.metric('Attendance %',f'{pct:.1f}%','Leave and Holiday excluded')
  if user['role'] in ('admin','team_lead'):
   with connect() as c:ins=[dict(x) for x in c.execute('SELECT intern_id,full_name FROM interns WHERE active=1'+(' AND team_id=?' if user['role']=='team_lead' else ''),((user['team_id'],) if user['role']=='team_lead' else ()))]
   if ins:
    with st.form('att'):
     intern=st.selectbox('Intern',ins,format_func=lambda x:f"{x['intern_id']} — {x['full_name']}");day=st.date_input('Date');status=st.selectbox('Attendance',['Present','Absent','Leave','Holiday']);remarks=st.text_input('Remarks');ok=st.form_submit_button('Record attendance')
    if ok:
     with connect() as c:c.execute('INSERT INTO attendance(intern_id,attendance_date,status,remarks,recorded_by) VALUES(?,?,?,?,?) ON CONFLICT(intern_id,attendance_date) DO UPDATE SET status=excluded.status,remarks=excluded.remarks,recorded_by=excluded.recorded_by',(intern['intern_id'],str(day),status,remarks,user['username']))
     audit(user['username'],'record_attendance','attendance',f"{intern['intern_id']}:{day}");st.success('Attendance saved')
  st.dataframe(pd.DataFrame(rows),use_container_width=True,hide_index=True)
 elif page=='Assessments':
  df=pd.DataFrame([x for x in tasks(user) if x['status'] in ('Submitted','Reviewed')]);st.dataframe(df,use_container_width=True,hide_index=True)
  if user['role'] in ('admin','team_lead') and not df.empty:
   opts=df.to_dict('records')
   with st.form('review'):
    t=st.selectbox('Task',opts,format_func=lambda x:f"{x['task_id']} — {x['title']}");result=st.selectbox('Result',['Passed','Needs Revision']);comment=st.text_area('Reviewer comments');ok=st.form_submit_button('Save review')
   if ok:
    if not allowed(user,t['team_id'],t['intern_id']):st.error('Unauthorized team scope')
    else:
     t.update(status='Reviewed',assessment_status=result,reviewer_comments=comment,reviewed_by=user['username']);save_task(t,user['username']);st.success('Assessment saved');st.rerun()
 elif page=='Deadline Monitoring':
  for key,label in [('overdue','Overdue'),('due_today','Due today'),('upcoming','Upcoming'),('review_pending','Review pending'),('revision','Needs revision')]:
   st.subheader(label);rows=deadlines(user)[key];st.dataframe(pd.DataFrame(rows),use_container_width=True,hide_index=True) if rows else st.caption('No records');
   if rows:st.download_button(f'Export {label}',pd.DataFrame(rows).to_csv(index=False).encode(),f'{key}.csv',key=key)
 elif page=='Reports & Exports':
  kind=st.selectbox('Report',['Intern Master','Task Register','Pending Tasks','Overdue Tasks','Upcoming Deadlines','Assessment Report','Team Follow-up'])
  if kind=='Intern Master':
   with connect() as c:rows=[dict(x) for x in c.execute('SELECT * FROM interns'+(' WHERE team_id=?' if user['role']=='team_lead' else ' WHERE intern_id=?' if user['role']=='intern' else ''),((user['team_id'],) if user['role']=='team_lead' else (user['intern_id'],) if user['role']=='intern' else ()))]
  else:
   rows=tasks(user)
   if kind=='Pending Tasks':rows=[x for x in rows if x['status']!='Reviewed']
   if kind=='Overdue Tasks':rows=deadlines(user)['overdue']
   if kind=='Upcoming Deadlines':rows=deadlines(user)['upcoming']
   if kind=='Assessment Report':rows=[x for x in rows if x['status']=='Reviewed']
   if kind=='Team Follow-up':rows=deadlines(user)['overdue']+deadlines(user)['review_pending']+deadlines(user)['revision']
  df=pd.DataFrame(rows);st.caption(f'{len(rows)} record(s)');st.dataframe(df,use_container_width=True,hide_index=True) if rows else st.info('No records match selected report')
  st.download_button('Download Excel/CSV',df.to_csv(index=False).encode(),kind.lower().replace(' ','_')+'.csv')
  buff=BytesIO();doc=SimpleDocTemplate(buff,pagesize=landscape(A4));styles=getSampleStyleSheet();story=[Paragraph('DefineInfoTech Pvt. Ltd. — '+kind,styles['Title']),Paragraph('Generated '+str(date.today()),styles['Normal'])]
  if rows:
   cols=list(rows[0])[:7];story.append(Table([cols]+[[str(r.get(k,''))[:45] for k in cols] for r in rows[:150]],repeatRows=1,style=TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#102D58')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('GRID',(0,0),(-1,-1),.4,colors.grey),('FONTSIZE',(0,0),(-1,-1),7)])))
  else:story.append(Paragraph('No records match selected filters.',styles['Normal']))
  doc.build(story);st.download_button('Download PDF',buff.getvalue(),kind.lower().replace(' ','_')+'.pdf',mime='application/pdf');audit(user['username'],'report_export','report',kind)
 elif page=='Excel Import Center':
  from services.csv_import_service import import_records, SCHEMAS
  st.subheader('Validated CSV / Excel Import')
  st.info('Import is atomic: if any row has a validation error, the entire file is rejected and nothing is saved. Existing IDs are not overwritten.')
  template_dir=Path(__file__).parent/'templates'
  for base,cols in SCHEMAS.items():
   c1,c2=st.columns(2)
   with c1:
    csv_path=template_dir/(base+'_template.csv')
    if csv_path.exists(): st.download_button('Download '+base+'.csv',csv_path.read_bytes(),base+'.csv',mime='text/csv',key='csv_'+base)
   with c2:
    xlsx_path=template_dir/(base+'_template.xlsx')
    if xlsx_path.exists(): st.download_button('Download '+base+'.xlsx',xlsx_path.read_bytes(),base+'.xlsx',mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',key='xlsx_'+base)
  up=st.file_uploader('Upload completed CSV or XLSX template — import runs automatically',type=['csv','xlsx'],key='actual_import_upload')
  if up:
   if up.size>5*1024*1024: st.error('Maximum upload size is 5 MB.')
   else:
    import hashlib
    payload=up.getvalue()
    signature=hashlib.sha256(up.name.encode('utf-8')+payload).hexdigest()
    if st.session_state.get('last_import_signature') != signature:
     with st.spinner('Automatically validating and importing records…'):
      result=import_records(up.name,payload,user['username'])
      st.session_state['last_import_result']=result
      st.session_state['last_import_signature']=signature
     if result['imported']:
      st.success(f"Automatic import complete: {result['imported']} record(s) saved to the database.")
      st.rerun()
     elif result['errors']:
      st.error('Automatic import stopped safely. No records were saved because validation failed.')
    else:
     st.caption('This exact file has already been processed in this session; it will not be imported twice automatically.')
  result=st.session_state.get('last_import_result')
  if result:
   st.markdown('### Latest import result')
   a,b,c,d=st.columns(4)
   a.metric('Records read',result['read']);b.metric('Imported',result['imported']);c.metric('Rejected',result['rejected']);d.metric('Duplicates',result['duplicates'])
   if result['imported']:
    st.success(f"Successfully imported {result['imported']} record(s) into the database.")
   elif result['read'] and result['errors']:
    st.error('Import cancelled. No rows were saved because validation failed.')
   if result['errors']:
    err_df=pd.DataFrame(result['errors'])
    st.dataframe(err_df,use_container_width=True,hide_index=True)
    st.download_button('Download validation error report',err_df.to_csv(index=False).encode('utf-8-sig'),'import_validation_errors.csv','text/csv',key='download_import_errors')
   if result['read']==0 and not result['errors']:
    st.warning('The uploaded file did not contain any records.')
 elif page=='Data Quality':
  issues=[]
  with connect() as c:
   for label,sql in [('Task intern/team mismatch',"SELECT task_id FROM tasks t JOIN interns i USING(intern_id) WHERE t.team_id<>i.team_id"),('Reviewed without review history',"SELECT task_id FROM tasks WHERE status='Reviewed' AND task_id NOT IN (SELECT task_id FROM reviews)")]:
    issues += [{'Issue':label,'Record':r[0],'Resolution':'Open'} for r in c.execute(sql)]
  st.dataframe(pd.DataFrame(issues),use_container_width=True,hide_index=True) if issues else st.success('No detected data-quality issues')
 elif page=='Audit Logs':
  with connect() as c:st.dataframe(pd.read_sql_query('SELECT * FROM audit_logs ORDER BY audit_id DESC LIMIT 1000',c),use_container_width=True,hide_index=True)
 elif page=='User Management':
  with connect() as c:st.dataframe(pd.read_sql_query('SELECT username,role,intern_id,team_id,active FROM users',c),use_container_width=True,hide_index=True)
  with st.form('useradd'):
   u=st.text_input('Username');p=st.text_input('Temporary password (12+ chars)',type='password');role=st.selectbox('Role',['admin','team_lead','intern']);iid=st.text_input('Intern ID (intern role)');tid=st.text_input('Team ID (team lead role)');ok=st.form_submit_button('Create user')
  if ok:
   if len(p)<12:st.error('Password must be at least 12 characters')
   else:
    with connect() as c:c.execute('INSERT INTO users(username,password_hash,role,intern_id,team_id) VALUES(?,?,?,?,?)',(u,hash_password(p),role,iid or None,tid or None))
    audit(user['username'],'create_user','user',u);st.success('User created')
 elif page=='Backup & Settings':
  if st.button('Create verified backup'):st.success('Backup created: '+str(backup()))
  st.caption('Restoration is intentionally a documented offline operation: stop Streamlit, validate backup with SQLite PRAGMA integrity_check, retain a safety copy, then replace the configured database file.')
 elif page=='User Guide':
  st.markdown('''- Create teams first, then intern records, then tasks.\n- Completion = Passed assessments / all assigned tasks × 100.\n- Attendance = Present / (Present + Absent) × 100; Leave and Holiday are excluded.\n- Overdue excludes submitted/reviewed tasks; due today is separate; upcoming window defaults to 3 calendar days.\n- Demo records are synthetic. Change demo credentials before real use.\n- Company branding: the supplied original DefineInfoTech logo is included at `assets/dit_logo.png` and appears in the sidebar. This build opens directly in local demo mode without login; do not expose it to public/shared networks.''')
 elif page=='Change Password':
  with st.form('pw'):
   old=st.text_input('Current password',type='password');new=st.text_input('New password (12+ chars)',type='password');ok=st.form_submit_button('Change')
  if ok:
   with connect() as c:r=c.execute('SELECT password_hash FROM users WHERE username=?',(user['username'],)).fetchone()
   if not r or not verify_password(old,r[0]):st.error('Current password incorrect')
   elif len(new)<12:st.error('Password must be 12+ characters')
   else:
    with connect() as c:c.execute('UPDATE users SET password_hash=? WHERE username=?',(hash_password(new),user['username']))
    st.success('Password updated')

st.warning('DEMO MODE: Login is disabled and the app opens directly. Use only on your own computer; do not deploy this build to a public or shared network.')
main(st.session_state.user)
