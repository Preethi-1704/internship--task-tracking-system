# User Guide
1. Configure `.env`, set `ADMIN_INITIAL_PASSWORD` to 12+ characters, then launch `streamlit run app.py`.
2. Add teams before interns, then assign tasks.
3. Team leads see their assigned team; interns see their own records.
4. Use Deadline Monitoring for overdue, due-today, upcoming, review-pending and revision lists.
5. Reports & Exports provides CSV and PDF downloads.
6. Use Backup & Settings before maintenance. Restore offline only after checking SQLite integrity.


### Opening the app
This demonstration build opens directly to the dashboard without a login page. It runs as a demo administrator and may initialize synthetic demo data if the database is empty. Authentication is disabled; use only locally and never with real confidential data or on a public/shared network.
